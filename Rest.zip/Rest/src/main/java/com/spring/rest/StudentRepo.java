package com.spring.rest;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface StudentRepo extends JpaRepository<Student, Integer> {
    Student findByName(String name);

    List<Student> countByAge(int id);


    //@Query(value = "select  Student .id,Student .name from Student  inner join  Course on Student.id=Student.course.sid where Student.id=:id")
    //  Student getStudentCourse(int id);


}
