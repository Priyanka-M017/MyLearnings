package com.spring.rest;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;


@Service
@Component
public class Studentservice {
    @Autowired
    StudentRepo studentRepo;
    @PersistenceContext
    EntityManager entityManager;

    public List<Student> getallstudents() {

        return studentRepo.findAll();

        // return l;
    }

    public Student getstudentbyid(int id) {

        /**   if(hm.containsKey(id))
         return hm.get(id);
         else
         throw  new RuntimeException("NOW STDUENT FOUN BY"+id);
         ***/
        return studentRepo.findOne(id);

    }


    public Student getstudentbyname(String name) {


        return studentRepo.findByName(name);
    }

    public Student saveStudent(Student s) {


        return studentRepo.saveAndFlush(s);
    }

    public List<Student> countAge(int age) {

        return studentRepo.countByAge(age);
    }


    public Student getStudentcourse(int id) {

        /***** SessionFactory sessionFactory = new Configuration().configure("application.properties").buildSessionFactory();
         Session session = sessionFactory.openSession();
         Transaction t=session.beginTransaction();
         Student s1=session.get(Student.class,id);
         t.commit();
         session.close();******/


        return entityManager.find(Student.class, id);


    }

    public void deletestudent(int id) {

        studentRepo.delete(id);
    }


}
