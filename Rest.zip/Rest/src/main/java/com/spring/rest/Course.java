package com.spring.rest;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
@XmlRootElement(name = "courses")
@Entity
@Table(name = "courses")
public class Course {


    @Id
    // @Column(name ="course_id" )
    @ApiModelProperty(required = true)
    int sid;
    @Column(name = "course_name")
    @ApiModelProperty(required = true)
    String coursename;


    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public Course() {

    }

    public Course(int sid, String coursename) {

        this.sid = sid;
        this.coursename = coursename;

    }


}
