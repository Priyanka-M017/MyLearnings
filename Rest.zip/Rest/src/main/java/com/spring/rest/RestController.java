package com.spring.rest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.PathParam;
import javax.ws.rs.core.Application;
import java.util.*;


@org.springframework.web.bind.annotation.RestController
@RequestMapping("/rest")
@Api(value = "Studentservice", description = "Operations on student service")
public class RestController {
    @Autowired
    Studentservice s;


    @RequestMapping(value = "/allstudents", method = RequestMethod.GET)
    @ApiOperation(value = "list all the students", response = Student.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })
    public List<Student> getAllStudents() {

        List<Student> student = s.getallstudents();
        return student;

    }


    @RequestMapping(value = "/student/{id}", method = RequestMethod.GET)
    public ResponseEntity<Object> getStudentById(@PathVariable("id") int id) throws CustomExceptions {

        Map<String, String> responseBody = new HashMap<>();

        responseBody.put("message", "No records found with given student id");
        responseBody.put(String.valueOf(id), "not found");

        Student student = s.getstudentbyid(id);
        if (student != null)

            return new ResponseEntity<Object>(student, HttpStatus.FOUND);
        else
            return new ResponseEntity<Object>(responseBody, HttpStatus.NOT_FOUND);

    }

    @ResponseBody
    @RequestMapping(value = "/studentname", method = RequestMethod.GET)
    public Student getStudentByName(@RequestParam(name = "name") String name) throws CustomExceptions {


        return s.getstudentbyname(name);
    }

    @RequestMapping(value = "/addstudent", method = RequestMethod.POST)
    public ResponseEntity<Object> savestudent(@RequestBody Student student) {
        //Student save = new Student();
        //Course c1=new Course(student.id,student.);

        // save.setId(student.id);
        // save.setName(student.name);
        //save.setAge(student.age);
        //List<Course> course1=new ArrayList<Course>();
        //course1.add(c1);
        //save.setCourse(course1);
        Map<String, Object> response = new HashMap<String, Object>();
        response.put("message", "record sucessfully posted");
        response.put("request body", student);


        if (student == null) {

            return new ResponseEntity<Object>(student, HttpStatus.BAD_REQUEST);
        } else {
            s.saveStudent(student);
            // System.out.print("***********" + student.getCourse().forEach(course -> System.out.print(course.getSid())););
            return new ResponseEntity<Object>(response, HttpStatus.CREATED);
        }

    }

    @RequestMapping(value = "/course/{id}", method = RequestMethod.GET)
    public Student getStudentcourse(@PathVariable("id") int id) throws CustomExceptions {


        Student student = s.getStudentcourse(id);

        return student;


    }

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public void deletestudent(@PathVariable("id") int id) {

        s.deletestudent(id);
    }


}
