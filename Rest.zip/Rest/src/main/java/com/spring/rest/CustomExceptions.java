package com.spring.rest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Created by 1126276 on 3/17/2017.
 */
@ControllerAdvice
@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "data not found", code = HttpStatus.NOT_FOUND)
public class CustomExceptions extends RuntimeException {


}
