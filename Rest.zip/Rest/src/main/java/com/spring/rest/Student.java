package com.spring.rest;


import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.*;

/**
 * Created by 1126276 on 3/9/2017.
 */
@XmlRootElement(name = "Sudents")

@Entity(name = "student")
@Table(name = "students")
public class Student

{


    @Id
    @Column(name = "id")
    @ApiModelProperty(required = true)
    int id;
    @Column(name = "name")
    @ApiModelProperty(required = true)
    String name;
    @Column(name = "age")
    @ApiModelProperty(required = true)
    int age;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "sid", nullable = true)
    @ApiModelProperty(required = true)
    public List<Course> course;

    public Student(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public List<Course> getCourse() {
        return course;
    }

    public void setCourse(List<Course> course) {
        this.course = course;
    }

    public Student() {
    }
}
