--INSERT INTO Student(id,name,age) VALUES (1,'vinay', 40);
INSERT INTO Students(id,name,age) VALUES (2,'siva', 22);

