create table Students(
      id int not null primary key,
      name varchar_ignorecase(50) not null,

      age int);

            create table Courses(
      id int not null primary key,
      coursename varchar_ignorecase(50) not null
  );

