package com.tech.data.Mapping;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections4.MultiValuedMap;
import org.apache.commons.collections4.multimap.ArrayListValuedHashMap;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Test3 {

	public static void main(String[] args) throws IOException {
		
		//MultiValuedMap<String,String>hm=File("C:\\Users\\pmuthyala\\FI\\Legacy.xlsx");//Legacy Excel
		//MultiValuedMap<String,String>hm1=File("C:\\Users\\pmuthyala\\FI\\Modern.XLSX");//Modern Excel
		
		MultiValuedMap<String,String>hm=File("C:\\Users\\robaig\\Documents\\HCSC project\\Legacy.xlsx");//Legacy Excel
		MultiValuedMap<String,String>hm1=File("C:\\Users\\robaig\\Documents\\HCSC project\\Modern.xlsx");//Modern Excel
		
		String[] str ="ABC~1112233~01012020~12312020~MEM001~DowJones~LifeAndAnnuity DEF~1112244~01012021~12312021~MEM002~DowJames~Medicare".replaceAll("~", " ").split("\\s");
		String[] str1 ="ABC~1112233~0101202012312020~MEM001DowJones~LifeAndAnnuity DEF~1112244~0101202013412021~MEM002DowJames~Medicare".replaceAll("~", " ").split("\\s");
		
		String firstExcel="Legacy1.xlsx";
	    String SecondExcel="Modern1.xlsx";
	    String Excel="Results.xlsx";
	   
	    // String firstInput ="C:\\Users\\pmuthyala\\Documents\\Legacy1.xlsx";
	    //String secondInput ="C:\\Users\\pmuthyala\\Documents\\Modern1.xlsx";
	    
	    String firstInput ="C:\\Users\\robaig\\Documents\\Legacy1.xlsx";
	    String secondInput ="C:\\Users\\robaig\\Documents\\Modern1.xlsx";
	    
	    HashMapToExcel(hm,str,firstExcel);
		HashMapToExcel(hm1,str1,SecondExcel);
		//populateDataToCompare(firstInput, secondInput,firstExcelc);
		SplitTheCellOfModern(secondInput,firstInput,Excel);
}
	
private static void SplitTheCellOfModern(String secondInput, String firstInput, String Excel) throws IOException {
	
	FileInputStream file1=new FileInputStream(new File(secondInput));
	FileInputStream file2=new FileInputStream(new File(firstInput)); 
	XSSFWorkbook wb1 = new XSSFWorkbook(file1);
	XSSFWorkbook wb2 = new XSSFWorkbook(file2);
	XSSFSheet sheet = wb1.getSheet("data");
	XSSFSheet sheet2 = wb2.getSheet("data");
	int rows = sheet.getLastRowNum();
	int rows2 = sheet2.getLastRowNum();
	
	List<String> list=new ArrayList<String>();
	for(int i=0;i<=rows;i++)
	{
		if(sheet.getRow(i).getCell(1).getStringCellValue().equalsIgnoreCase("Policy Duration"))
		{
			list.add(sheet.getRow(i).getCell(2).getStringCellValue().substring(0,8));
			list.add(sheet.getRow(i).getCell(2).getStringCellValue().substring(8,16));
			continue;
		}
		if(sheet.getRow(i).getCell(1).getStringCellValue().equalsIgnoreCase("Member Details"))
		{
			list.add(sheet.getRow(i).getCell(2).getStringCellValue().substring(0,6));
			list.add(sheet.getRow(i).getCell(2).getStringCellValue().substring(6));
			continue;
		}
		 list.add(sheet.getRow(i).getCell(2).getStringCellValue());
		//list.add(res);
	}
	System.out.println(list);
	Iterator<String> itr=list.iterator();
	for(int i=0;i<=rows2;i++)
	{
		String str=sheet2.getRow(i).getCell(2).getStringCellValue();
		while(itr.hasNext())
		{
			if(itr.next().equals(str))
			{
				sheet2.getRow(i).createCell(3).setCellValue(true);
				break;
			}
			else
				sheet2.getRow(i).createCell(3).setCellValue(false);
			break;
		}
		
	}
	FileOutputStream fos=new FileOutputStream("C:\\Users\\robaig\\Documents\\"+Excel);
	wb2.write(fos);
	wb2.close();
	fos.close();
	System.out.println("Excel writtened Successfully");
	
}

private static MultiValuedMap<String, String> File(String fileName) throws IOException {
		
		FileInputStream fis=new FileInputStream(new File(fileName));  
		 
		XSSFWorkbook wb=new XSSFWorkbook(fis);   
		XSSFSheet sheet=wb.getSheet("Sheet1");
		
		int rows=sheet.getLastRowNum();
		
		MultiValuedMap<String,String>hm=new ArrayListValuedHashMap<String,String>();
		
		for(int r=1;r<=rows;r++)
		{
			String key=sheet.getRow(r).getCell(0).getStringCellValue();
			String value=sheet.getRow(r).getCell(1).getStringCellValue();
			
			hm.put(key,value);
		}
		
		return hm;
	}

private static void HashMapToExcel(MultiValuedMap<String, String> hm,String[]res,String Excel) throws IOException {
		
		XSSFWorkbook wb=new XSSFWorkbook();   
		XSSFSheet sheet=wb.createSheet("data");
		int rowno=0;
		int temp=rowno;
		int i=0;
		for(Entry<String, String> entry:hm.entries())
		{
			
			XSSFRow row=sheet.createRow(rowno++);
			row.createCell(0).setCellValue(entry.getKey());
			row.createCell(1).setCellValue(entry.getValue());
			if(entry.getKey().equals(res[i]))
			{
				i++;
				row.createCell(2).setCellValue(res[i]);
			}
			else
			{
				row.createCell(2).setCellValue(res[i]);
			}
			i++;
			
		}
		FileOutputStream fos=new FileOutputStream("C:\\Users\\robaig\\Documents\\"+Excel);
		System.out.println("Excel returned Successfully");
		wb.write(fos);
		wb.close();
		fos.close();
	}
		
}

