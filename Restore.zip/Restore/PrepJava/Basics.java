How to increase the input dynamically :
class Student  
{ 
    String name; 
    int rollNo; 
      
    // static variable 
    static String cllgName; 
      
    // static counter to set unique roll no 
    static int counter = 0; 
      
      
    public Student(String name)  
    { 
        this.name = name; 
          
        this.rollNo = setRollNo(); 
    } 
      
    // getting unique rollNo 
    // through static variable(counter) 
    static int setRollNo() 
    { 
        counter++; 
        return counter; 
    } 
      
    // static method 
    static void setCllg(String name){ 
        cllgName = name ; 
    } 
      
    // instance method 
    void getStudentInfo(){ 
        System.out.println("name : " + this.name); 
        System.out.println("rollNo : " + this.rollNo); 
          
        // accessing static variable 
        System.out.println("cllgName : " + cllgName); 
    } 
} 
  
//Driver class 
public class StaticDemo  
{ 
    public static void main(String[] args) 
    { 
        // calling static method 
        // without instantiating Student class 
        Student.setCllg("XYZ"); 
      
        Student s1 = new Student("Alice"); 
        Student s2 = new Student("Bob"); 
          
        s1.getStudentInfo(); 
        s2.getStudentInfo(); 
          
    } 
} 
Output:

name : Alice
rollNo : 1
cllgName : XYZ
name : Bob
rollNo : 2
cllgName : XYZ

GarbageCollector :

Java garbage collection is the process by which Java programs perform automatic memory management. Java programs compile to bytecode that can be run on a Java Virtual Machine, or JVM for short. ... The garbage collector finds these unused objects(the objest who doesn't have any reference)  and deletes them to free up memory

Before deleting the unused objects, the garbage collector does the clean up activity by calling the finalize method to close the database connection or network connectionthat are associated with unused objects. Once the clean up activity is done the unused methods will be deleted.

Who calls the finalize method?
GarbageCollector
When GarbageCollector calls finalize method?
just before deleting the unused objects.
what is the purpose of calling finalize method?
to perform clean up activity
;

in a Temp class Whenever we try to print temp object, internally toString() method will be called.

What is the difference between FileReader and FileInputStream?
1) The first difference is in their type hierarchy, FileReader extends from Reader class while FileInputStream is descendent of InputStream class. 2) The second difference is in their purpose. The FileReader is meant for reading text data while FileInputStream is for reading binary data

System.out.println(new File(".").getAbsolutePath()); this line gives the absolute path of file


ArrayList L = new ArrayList();
		L.add("red");
		  L.add("blue");
		  L.add("white");
		  L.add("black");
		  
		  System.out.println(L);
		  ListIterator itr=L.listIterator();
		  
		  while(itr.hasNext()) {
			String s =(String) itr.next();
			if(s.equals("blue")) {
				itr.set("yellow");
				
			}
			
					}
			
		  System.out.println(L);	
		  
		  
		  
		  
Diamond access problem : Multiple inheritance, child class extending 2 parent classess with same m1() method and if child class tries access this method will get diamond acess problem


What is jsp in  java?

It is used for creating web application. It is used to create dynamic web content. In this JSP tags are used to insert JAVA code into HTML pages. ... In this, Java code can be inserted in HTML/ XML pages or both. JSP is first converted into servlet by JSP container before processing the client's request

What is jsp in  java?
JSTL stands for JSP Standard Tag Library. JSTL is the standard tag library that provides tags to control the JSP page behavior. JSTL tags can be used for iteration and control statements, internationalization, SQL etc.

Refer : https://www.youtube.com/watch?v=g2b-NbR48Jo&t=2162s
Spring MVC with Example (ModelAndView) - 31:17 to 35:15

Static block : Whenever we create a object, it will load the class first and once the class is loaded the static block will get executed and when the object is created the instance block will get created. That means static block gets loaded before even the class object is created

Practical:
How to load a class?

We can load a class by using Class.forName("className"); if we do this only the static block will get executed
Class.forName("className").newInstance(); will create the instance of class and loads the instance block

MySQL error code: 1175 during UPDATE in MySQL Workbench ?

It looks like your MySql session has the safe-updates option set. This means that you can't update or delete records without specifying a key (ex. primary key) in the where clause.

Try:

SET SQL_SAFE_UPDATES = 0;

if we want to share our files on internet, we use ftp protocol

Difference b/w URI & URL & URN

URI- uniform resource Identifier - which means a seraching for the resource either by the name or by location 
URL - Uniform resource Locator - searching for the resource by location
URN - Uniform resource Name - searching for the resource by name

this is the url of facebook login page : https://www.facebook.com /login : 

http - The protocol

www.facebook.com - Domain which is the name given to unique ip address of facebook

sometimes we also get port number in url 



where as login is the PATH of directory in the server 

There are some more optional things which are 
the port  :

what is port?
port is a type of software connection point used by the TCP/IP protocol and the computer connection. by specifying the port number, we are telling the server from which port the request is coming and which port should the response be received.

by default every protocol will have its own port number and we dont add any port number it will consider as default port. If we want to specify the port number in the url then we should give the port number after the domain name separated by a colon(:)

2. the path

3. query string or query parameters

4. fragments: which are indicated with #symbol like #html in the end of swagger url. Its represents that we are requesting for the some portion of page
 
 
yml file in cloud foundry? The file is an application deployment descriptor. This means that it contains information needed to deploy the application on cloud doundry e.g. name of the application, path to the application

use @PathParam for retrieval based on id. User @QueryParam for filter or if you have any fixed list of options that user can pass