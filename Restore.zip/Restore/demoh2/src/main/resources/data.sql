insert into student values (1,100.0,'Priyanka');
insert into student  values (2,99.9,'Sappa');