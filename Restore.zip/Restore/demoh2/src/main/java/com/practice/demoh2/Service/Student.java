package com.practice.demoh2.Service;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Student {
	
	@Id
	int RollNo;
	String Name;
	Double Marks;
	
    
	
	
	public String getName() {
		return Name;
	}
	
	
	public void setName(String name) {
		Name = name;
	}
	
	public int getRollNo() {
		return RollNo;
	}
	public void setRollNo(int rollNo) {
		RollNo = rollNo;
	}
	
	
	public Double getMarks() {
		return Marks;
	}
	public void setMarks(Double marks) {
		Marks = marks;
	}
	@Override
	public String toString() {
		return "Student [Name=" + Name + ", RollNo=" + RollNo + ", Marks=" + Marks + "]";
	}
}
