package com.practice.demoh2.doa;

import org.springframework.data.repository.CrudRepository;

import com.practice.demoh2.Service.Student;

public interface StudentRepo extends CrudRepository<Student, Integer>

{

}
