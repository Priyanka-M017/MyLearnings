package com.practice.demoh2.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.practice.demoh2.Service.Student;
import com.practice.demoh2.doa.StudentRepo;

@Controller
public class SchoolController {
	
	@Autowired
	StudentRepo Studrepo;
	
	
	@RequestMapping(value="/")
	public String login() {
		
		return "StudentLogin";
		}
	
	@RequestMapping(value="/addStudent")
	public String showStudentDetails(Student stu) {
		
		if(!((stu.getName()=="" || stu.getRollNo()==0 ) || (stu.getMarks()==null))) {
		Studrepo.save(stu);
		}
		return "DetailsStudent";
		}
	
	
	@RequestMapping(value="/StudentDetailsById")
	public String getStudent(@RequestParam int RollNo) {
		
		
		
		Studrepo.findById(RollNo);
		return "StudentDetailsById";
		}
	
	
	

}
