package com.practice.demoh2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoh2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
