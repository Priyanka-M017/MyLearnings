package com.tech.data.Mapping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class General{
	
	int id=4;
	String Name="SAP";
	Double marks=100.0;
	
	public static void main(String args[]) throws Exception{ 
		 
		int Id=7;
		String Name="Himaja";
		Double Marks=98.0;
		String Query="Insert into student values (?,?,?)";
		String Query1="Insert into student values (" + Id + ",'" + Name + "', " + Marks+ ")";
			
		
		
			Class.forName("com.mysql.cj.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pridb","root","Priy"); 
			Statement stmt=con.createStatement();  
			
			//select query
    		//ResultSet rs=stmt.executeQuery("select * from Student");  
    		//while(rs.next())  
    		//System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getDouble(3)); 
			
			//Update and can use insert in the same
    		//int count= stmt.executeUpdate("update student set Id=3 where Name='Sappa satish'");
    		//System.out.println(count + " updated in student table");
			
			int count2= stmt.executeUpdate(Query1);
    		System.out.println(count2 + " updated in student table");
    		
    		
//    		PreparedStatement ps=con.prepareStatement(Query);
//    		ps.setInt(1, Id);
//    		ps.setString(2, Name);
//    		ps.setDouble(3, Marks);
//    		
//    		int count1=ps.executeUpdate();
//    		System.out.println(count1 + " updated in student table");
    		con.close(); 
    		
    		}
		

	
	
	  }

	
	

	


