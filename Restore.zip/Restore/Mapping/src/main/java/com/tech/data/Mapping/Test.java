package com.tech.data.Mapping;

import java.io.File;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.microsoft.schemas.office.visio.x2012.main.CellType;

public class Test {

	public static void main(String[] args) throws IOException {
		
		HashMap<String,String>hm=new LinkedHashMap<>();
		HashMap<String,String>hm2=new LinkedHashMap<>();

		List<String>Key1=File("C:\\Users\\robaig\\Documents\\Book1.xlsx");
		List<String>Key2=File("C:\\Users\\robaig\\Documents\\Book2.xlsx");
		
		String str3[]=new String[Key2.size()];
		str3=Key2.toArray(str3);
		
		List<String>value=Arrays.asList("1123~tyur~5678~qwert~78675~java".split("~"));
		for (int i=0; i<Key1.size(); i++) 
		{
		      hm.put(Key1.get(i),value.get(i));    
		}
			System.out.println(hm);
		    String firstExcel="test1.xlsx";
		    String SecondExcel="test2.xlsx";

		    HashMapToExcel(hm,firstExcel);
		    
		    for(int i=0;i<str3.length;i++)
		    {
		    	for (Entry<String, String> pair : hm.entrySet())
		    	{
		    		if(pair.getKey().contains(str3[i]))
		    		{
		    		hm2.put(pair.getKey(), pair.getValue());
		    		}
		    	}	
		    }
		    System.out.println(hm2);
		    HashMapToExcel(hm2,SecondExcel);
		    
		    
	}
	
		private static void HashMapToExcel(HashMap<String, String> hm,String Excel) throws IOException {
			
			System.out.println(hm);
			XSSFWorkbook wb=new XSSFWorkbook();   
			XSSFSheet sheet=wb.createSheet("data");
			
			int rowno=0;
			for(Entry entry:hm.entrySet())
			{
				XSSFRow row=sheet.createRow(rowno++);
				row.createCell(0).setCellValue((String)entry.getKey());
				row.createCell(1).setCellValue((String)entry.getValue());

			}
			
			FileOutputStream fos=new FileOutputStream("C:\\Users\\robaig\\Documents\\"+Excel);
			wb.write(fos);
			fos.close();
			System.out.println("Excel returned Successfully");
		
	}

		private static List<String> File(String fileName) throws IOException {
		
		FileInputStream fis=new FileInputStream(new File(fileName));  
		 
		XSSFWorkbook wb=new XSSFWorkbook(fis);   
		XSSFSheet sheet=wb.getSheet("Sheet1");
		
		
		List<String> l=new ArrayList<String>();
		for(Row row: sheet)       
		{  
			for(Cell cell: row)      
			{  
				switch(cell.getCellType())  
				{  
				case Cell.CELL_TYPE_NUMERIC:				
				  
				cell.getNumericCellValue();   
				break;  
				case Cell.CELL_TYPE_STRING:    
					
				cell.getStringCellValue();
				break;  
			}  
			String s=cell.toString();
			
			l.add(s);
			}  
			System.out.println();  
		}
		
		return l;
		
	}

	/*
	 * private static List<String> findAccordingly(String str) {
	 * List<String>s=str.split("~"); return s; }
	 */
	
	
}
/*int i=0;
try
{
while(i<=res.length) {
for(Entry<String,String>entry:hm.entries())
{
	if(res[i].equals(entry.getKey()))
	{
		//System.out.println(entry.getKey());
		i++;
		break;
	}
	else
	{
	//	System.out.println(entry.getValue());
	//	System.out.println(res[i]);
		hm2.put(entry.getValue(),res[i]);
		i++;
		
	}
}
}
}
catch(Exception e)
{
	e.getCause();
}*/
