package com.tech.data.Mapping;

public class StudentDetails {
	
	static {
		System.out.println("Static block is executed");
	}
	
	{
		System.out.println("Instance block is executed");
	}
	
	
	
	

}
