package com.tech.data.Mapping;

public class Study {
	
	public static void main (String[] args) throws Exception{
		Class.forName("/Mapping/src/main/java/com/tech/data/Mapping/StudentDetails.java");
	}

}


