package com.myproj.EmployeeTO;

import java.sql.ResultSet;

import com.myproj.EmployeeDAO.EmpDAO;

public class EmployeeView {
	

	public static void main(String[] args) {
		
	EmpDAO empdao=new EmpDAO();
	
	try
	{
		empdao.allEmployees();
		empdao.allEmployees1();
		
		}
		catch (Exception e) {
			
		e.printStackTrace();
		}
	
	
	}
	

}
