package com.myproj.EmployeeTO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.myproj.EmployeeBean.Employee;
import com.myproj.EmployeeBean.EmployeePersonalInfo;
import com.myproj.EmployeeBean.EmployeeProfInfo;
import com.myproj.EmployeeDAO.EmpDAO;

public class EmployeeServices {
	
	
	public static void main(String[] args) {
		
		Employee employee=new Employee();
		EmployeePersonalInfo employeepersonalinfo=new EmployeePersonalInfo();
		EmployeeProfInfo employeeproinfo=new EmployeeProfInfo();
		EmpDAO empdao=new  EmpDAO();

		SimpleDateFormat dateformat=new SimpleDateFormat("dd-MM-yyyy");
	      Date dob=null;
	      try
	      {
	    	  dob=dateformat.parse("23-11-1996");
	      }
	      catch(ParseException e)
	      {
	    	  e.printStackTrace();
	      }
		
	      employee.setEmp_id(30);
	      employee.setEmp_fname("radhika");
	      employee.setEmp_mname("krishnakumar");
	      employee.setEmp_lname("singh");
	      employee.setEmp_dob(dob);
	      
		   employeepersonalinfo.setEmp_phone(2523791);
		   employeepersonalinfo.setEmp_address("Mumbai");
		   employeepersonalinfo.setEmp_email("radhi23@gmail.com");
		   employeepersonalinfo.setEmp_bloodgroup("o+ve");
		   
		   employeeproinfo.setEmp_desgn("Trainee");
		   employeeproinfo.setSalary(20000);
		   
		   int result=empdao.saveEmployeeDetails(employee, employeepersonalinfo, employeeproinfo);
	      if(result==1)
	      {
	    	  System.out.println("Employees Record Inserted");
	      }
	      else
	      {
	    	  System.out.println("Employees NOT Record Inserted");
	      }
	
	}

}
