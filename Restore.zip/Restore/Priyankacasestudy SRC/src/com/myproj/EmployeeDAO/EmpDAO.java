package com.myproj.EmployeeDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.myproj.EmployeeBean.Employee;
import com.myproj.EmployeeBean.EmployeePersonalInfo;
import com.myproj.EmployeeBean.EmployeeProfInfo;
import com.myproj.EmployeeDbConn.DbConn;

public class EmpDAO {
	
	
	public static int saveEmployeeDetails2(Employee employee,EmployeePersonalInfo employeepersonalinfo)
	{
		
		try{
		String sql2="Insert into employee_personal_info values(?,?,?,?,?)";
		Connection con=DbConn.getConnect();
		PreparedStatement stat2=con.prepareStatement(sql2);
		stat2.setInt(1,employee.getEmp_id());
		stat2.setInt(2,employeepersonalinfo.getEmp_phone());
		stat2.setString(3,employeepersonalinfo.getEmp_email());
		stat2.setString(4,employeepersonalinfo.getEmp_address());
		stat2.setString(5,employeepersonalinfo.getEmp_bloodgroup());
		
		int res2=stat2.executeUpdate();
		return res2;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		   
         return 0;
		
		}
		
	
	
	}
	
	
	public static int saveEmployeeDetails3(Employee employee,EmployeeProfInfo employeeproinfo)
	{
	
		try{
			String sql3="Insert into employee_prof_info values(?,?,?)";
			Connection con=DbConn.getConnect();
			PreparedStatement stat3=con.prepareStatement(sql3);
			stat3.setInt(1,employee.getEmp_id());
			stat3.setString(2,employeeproinfo.getEmp_desgn());
			stat3.setInt(3,employeeproinfo.getSalary());
			 int res3=stat3.executeUpdate();
			return res3;
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
		   
         return 0;
		
		}
	}
	
	public static int saveEmployeeDetails(Employee employee,EmployeePersonalInfo employeepersonalinfo,EmployeeProfInfo employeeproinfo)
	{
		try{
			String sql1="Insert into employee values(?,?,?,?,?)";
		
		Connection con=DbConn.getConnect();
		PreparedStatement stat=con.prepareStatement(sql1);
		stat.setInt(1,employee.getEmp_id());
		stat.setString(2, employee.getEmp_fname());
		stat.setString(3, employee.getEmp_mname());
		stat.setString(4, employee.getEmp_lname());
		Date dob=new Date(employee.getEmp_dob().getYear(),employee.getEmp_dob().getMonth(),employee.getEmp_dob().getDate());
		stat.setDate(5, dob);
		int res1=stat.executeUpdate();
		
		
		int result2=saveEmployeeDetails2(employee, employeepersonalinfo);
		int result3=saveEmployeeDetails3(employee, employeeproinfo);
		if(res1>0 && result2>0 && result3>0)
		 {
			 return 1;
		 }
		 else
		 {
			 return 0;
		 }
		
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
		   
         return 0;
		
		}
		
		
		
		
		
	
	}
	

	
	
	public void allEmployees()
	{
		try
		{
	  Connection con=DbConn.getConnect();
	
	  String sql4="select emp_fname|| '  ' || emp_mname || ' ' ||emp_lname,dept_name from employee join works on employee.emp_id=works.emp_id join department on department.dept_id=works.dept_id";
		

		PreparedStatement stat5=con.prepareStatement(sql4);
		ResultSet res4= stat5.executeQuery();
		while(res4.next())
		{
			String name= res4.getString(1);
			String de= res4.getString(2);
			System.out.println(name +""+de);
	System.out.println(res4.getString(1)+" "+res4.getString(2));		
			
		}
	
		}
		catch (Exception e) {
			e.printStackTrace();	
		
		}
	}
	
	
	
	
	
	public void allEmployees1()
	{
		try
		{
		Connection con=DbConn.getConnect();
		String sql5=" select avg(emp_salary),dept_name from employee_prof_info join works on employee_prof_info.emp_id=works.emp_id join department on department.dept_id=works.dept_id group by dept_name";
		PreparedStatement stat6=con.prepareStatement(sql5);
		ResultSet res6= stat6.executeQuery();
		while(res6.next())
		{
	System.out.println(res6.getString(1)+" "+res6.getString(2));		
			
		}
	
		
		}
		catch (Exception e) {
			e.printStackTrace();	
		
		}
	}
	
	
	
}
