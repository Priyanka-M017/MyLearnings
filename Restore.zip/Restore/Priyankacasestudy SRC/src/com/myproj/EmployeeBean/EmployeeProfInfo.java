package com.myproj.EmployeeBean;

public class EmployeeProfInfo {
	
	private String emp_desgn;
	private  int salary;
	
	 public EmployeeProfInfo()
	 {
		 
	 }

	public String getEmp_desgn() {
		return emp_desgn;
	}

	public void setEmp_desgn(String emp_desgn) {
		this.emp_desgn = emp_desgn;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	 
	 

}
