package com.myproj.EmployeeBean;

public class EmployeePersonalInfo {
 
	private int emp_phone;
	private String emp_email;
	private String emp_address;	
	private String emp_bloodgroup;
	
	public EmployeePersonalInfo()
	{
		
	}

	public int getEmp_phone() {
		return emp_phone;
	}

	public void setEmp_phone(int emp_phone) {
		this.emp_phone = emp_phone;
	}

	public String getEmp_email() {
		return emp_email;
	}

	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}

	public String getEmp_address() {
		return emp_address;
	}

	public void setEmp_address(String emp_address) {
		this.emp_address = emp_address;
	}

	public String getEmp_bloodgroup() {
		return emp_bloodgroup;
	}

	public void setEmp_bloodgroup(String emp_bloodgroup) {
		this.emp_bloodgroup = emp_bloodgroup;
	}
	
	
	

}
