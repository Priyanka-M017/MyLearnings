package com.practice.spring.security.Springsecurityjwt.Model;

public class AutenticationResponse {
	
	String JWT;

	public String getJWT() {
		return JWT;
	}

	public AutenticationResponse(String jWT) {
		JWT = jWT;
	}

	
	
	

}
