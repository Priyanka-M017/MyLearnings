package com.practice.spring.security.Springsecurityjwt.Controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.practice.spring.security.Springsecurityjwt.Model.AutenticationRequest;
import com.practice.spring.security.Springsecurityjwt.Model.AutenticationResponse;
import com.practice.spring.security.Springsecurityjwt.Util.UtilJWT;




@RestController
public class SecutityImp {
	
	@Autowired
	private AuthenticationManager  authenticationManager;
	
	@Autowired
	UtilJWT utilJWT;
	
	@Autowired
	private UserDetailsService userDetailsService;

	
	
	
	
	@RequestMapping("/hello")
 public String login() {
	
		return "Hurrayyy I did ittttt";
		}
	
	@RequestMapping(value="/authentication", method=RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AutenticationRequest autenticationRequest){
		
		try {
	authenticationManager.authenticate( 
	  new UsernamePasswordAuthenticationToken(autenticationRequest.getUsername(), autenticationRequest.getPassword()));
		}
		catch(AuthenticationException e) {
			e.printStackTrace();
		}
		
		final UserDetails userDetails = userDetailsService.loadUserByUsername(autenticationRequest.getUsername());
		
		final String jwt=utilJWT.generateToken(userDetails);
		
	return ResponseEntity.ok(new AutenticationResponse(jwt));
	}
	
	
	
}
