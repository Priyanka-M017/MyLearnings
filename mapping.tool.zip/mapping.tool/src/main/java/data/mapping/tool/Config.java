package data.mapping.tool;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

public class Config {
	
	public String getPropValues(String key) throws IOException {
		
		String propFileName="";
		try {
			Properties prop=new Properties();
		InputStream ip= getClass().getClassLoader().getSystemResourceAsStream("config.properties");
			prop.load(ip);
			propFileName = prop.getProperty(key);
		}
		catch(Exception e) {
		}
		return propFileName;
	
	}
   Date time =new Date(System.currentTimeMillis());
}
