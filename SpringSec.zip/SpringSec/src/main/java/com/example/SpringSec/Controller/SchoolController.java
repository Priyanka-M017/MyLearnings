package com.example.SpringSec.Controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringSec.Service.Student;

@RestController
@RequestMapping("/api/v1/students")
public class SchoolController {
	
	Student s1=new Student(1,"Priyanka");
	Student s2=new Student(2,"Muthyala");
	Student s3=new Student(3,"Sappa");
	
	public static List<Student> Studs= Arrays.asList(
			
			new Student(1,"Priyanka"),
			new Student(2,"Sappa"),
			new Student(2,"Muthyala")
			
			
			);
	
	
	
	
	
	@GetMapping(path = "{id}")
	public Student getStudent(@PathVariable("id") Integer studentId){
		System.out.println(studentId);
		return Studs.stream().filter(student -> studentId.equals(student.getStudentId())).findFirst()
				.orElseThrow(() -> new IllegalStateException("Student " + studentId + "is not found"));
	}

	@GetMapping("All")
	public List<Student> allStudent(){
		return Studs;
				
	}
	
	
}

