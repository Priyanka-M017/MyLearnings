package com.prac.hibernateDemo;

public class Student {
	
	int id;
	String Name;
	Double Marks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Double getMarks() {
		return Marks;
	}
	public void setMarks(Double marks) {
		Marks = marks;
	}

}
