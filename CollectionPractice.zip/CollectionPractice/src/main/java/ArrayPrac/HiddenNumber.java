package ArrayPrac;

import java.util.Arrays;
import java.util.List;

public class HiddenNumber {

	
	public static void main(String[] args) {
//	    String s = "hello worlz";
//	    s = s.replace(" ", "");
//	    char[] c = s.toCharArray();
//
//	    for (Character ss : c)
//	        System.out.println(ss - 'a' + 1);
		
		
		List a = Arrays.asList("a","f","c");
		
		if(!(a.get(0).equals(a))) {
			System.out.println("f");
		}
		else {
			System.out.println("p");
		}
	}
	
	
}
