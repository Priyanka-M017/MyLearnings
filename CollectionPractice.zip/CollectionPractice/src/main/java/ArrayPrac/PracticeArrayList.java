package ArrayPrac;


import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;


public class PracticeArrayList {
	
	public static void main(String args[]) {
	
	//List<String> Al = Arrays.asList("red","blue","green");
    ArrayList<String> al= new ArrayList<String>();
    
    al.add("red");
    al.add("color");
    al.add(1, "first");
    Collections.sort(al);
    
    System.out.println(al);
    System.out.println(al.get(1));
    System.out.println(al.remove(2));
    System.out.println(al.isEmpty());
    
    
    System.out.println(al);
    ArrayList<String> al1= new ArrayList<String>();
    
    al1.addAll(al);
    al1.add("al + al1");
    al1.add("pink");
    al1.add("white");
    al1.add(1, "red");
   System.out.println("Befor :" + al1);
    Collections.shuffle(al1);
    System.out.println("After :" +al1);
   System.out.println(al1.subList(0, 5));
   System.out.println("Befor :" + al1);
   Collections.swap(al1, 4, 5);
   System.out.println("After :" +al1);
   
    
    ArrayList al3 = new ArrayList();
    
    for(String s:al1) {
    	al3.add(al.contains(s)?"Yes" :"No");
    	
    }
    
    System.out.println(al3);
    
	}
}
