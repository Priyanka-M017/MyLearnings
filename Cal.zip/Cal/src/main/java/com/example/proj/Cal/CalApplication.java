package com.example.proj.Cal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exmaple.proj.Cal.Service.Student;

@SpringBootApplication
public class CalApplication  {
	
	@Autowired
	//private com.exmaple.proj.Cal.Repo.StudentRepo StudentRepo;

	public static void main(String[] args) {
		SpringApplication.run(CalApplication.class, args);
	
	}
	
//	public void run(String... arg0)  throws Exception{
//		
//		System.out.println("inside run");
//		StudentRepo.insert(new Student(10,"Devika", 100.00));
//		System.out.println("Inserted");
//	
//	
//}
}