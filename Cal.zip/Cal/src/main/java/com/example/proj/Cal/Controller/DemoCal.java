package com.example.proj.Cal.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.exmaple.proj.Cal.Repo.StudentRepo;
import com.exmaple.proj.Cal.Service.Student;

@Controller
public class DemoCal {

	
//	@RequestMapping(value="/", method=RequestMethod.GET)
//	public String hiMsg() {
//		return "Hi";
//	}
	
	@GetMapping(value="/hello")
	@ResponseBody
	public String login() {
		
		return "Hellow world";
		}
	
	@GetMapping(value="/check")
	@ResponseBody
	public String check() {
	  StudentRepo.insert(new Student(11,"Sivasankar", 75.00));
	  return "inserted";
		}
	
	
	
}
