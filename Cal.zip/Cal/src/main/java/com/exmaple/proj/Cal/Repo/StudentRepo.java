package com.exmaple.proj.Cal.Repo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Repository;

import com.exmaple.proj.Cal.Service.Student;
import com.mysql.cj.xdevapi.PreparableStatement;

@Repository
public class StudentRepo {
	
	@Autowired
	private static JdbcTemplate jdbcTemplate;

	
	public static void insert(Student stu) {
		String sql= "Insert into Student" + "(Id, Name, Marks) values (?, ?, ?)";
		
		jdbcTemplate.update(new PreparedStatementCreator() 
		{
			
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement ps = con.prepareStatement(sql);
				
				ps.setInt(1, stu.getId());
				ps.setString(2, stu.getName());
				ps.setDouble(3, stu.getMarks());
				
				
				
				return ps;
				
				
				
			}
			
			
			
			
			
		}
				
				
				
				
				
				
				
				
				
				);
		
		
		
		
	}
	
	
}
