package com.exmaple.proj.Cal.Service;

public class Student {
	
	
	int Id;
	String Name;
	Double Marks;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public Double getMarks() {
		return Marks;
	}
	public void setMarks(Double marks) {
		Marks = marks;
	}
	@Override
	public String toString() {
		return "Student [Name=" + Name + ", Id=" + Id + ", Marks=" + Marks + "]";
	}
	public Student(int id, String name, Double marks) {
		super();
		Id = id;
		Name = name;
		Marks = marks;
	}
	
	
	
	
	
	
}
