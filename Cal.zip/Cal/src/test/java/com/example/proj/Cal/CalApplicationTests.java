package com.example.proj.Cal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalApplicationTests {

	@Test
	void contextLoads() {
	}

}
