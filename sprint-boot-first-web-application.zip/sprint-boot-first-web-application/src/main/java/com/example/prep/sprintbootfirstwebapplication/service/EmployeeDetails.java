package com.example.prep.sprintbootfirstwebapplication.service;

public class EmployeeDetails {
	
	String id;
	String EmpNo;
	double salary;
	
	public String getid() {
		return id;
	}
	public void setEmpid(String id) {
		id = id;
	}
	public String getEmpNo() {
		return EmpNo;
	}
	public void setEmpNo(String empNo) {
		EmpNo = empNo;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}

}
