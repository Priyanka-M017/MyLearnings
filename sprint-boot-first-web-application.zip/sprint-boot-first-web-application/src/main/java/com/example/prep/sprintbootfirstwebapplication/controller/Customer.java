package com.example.prep.sprintbootfirstwebapplication.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.prep.sprintbootfirstwebapplication.service.EmployeeDetails;



@RestController
@RequestMapping("/api")
public class Customer {

	
		
		ConcurrentHashMap<String, EmployeeDetails> emps= new ConcurrentHashMap<>();
		
		
		
//		@RequestMapping("/hello")
//		public String login() {
//			
//			return "Hellow world";
//			}
		
		@GetMapping("/{id}")
		public EmployeeDetails getEmployeeByid(@PathVariable String id) {
			return emps.get(id);
			
		}
		
		@PostMapping("/")
		public EmployeeDetails addEmployee(@RequestBody EmployeeDetails emp) {
			emps.put(emp.getid(), emp);
			return emp;
			
		
		}
		
		@GetMapping("/")
		public List<EmployeeDetails> getAllEmployees() {
			return new ArrayList<EmployeeDetails>(emps.values());
			
			
		
		
	}
}
