package com.example.prep.sprintbootfirstwebapplication.service;

import org.springframework.stereotype.Component;

@Component
public class LoginService {
	
	public boolean userValidation(String UserId, String Password) {
		return UserId.equalsIgnoreCase("Priyanka") &&
				Password.equalsIgnoreCase("m");
		
		
	}

}
