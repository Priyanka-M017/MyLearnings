package com.practice.spring.security.Springsecurityjwt.Services;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id="ownactu")
public class OwnActu {
	
	@ReadOperation
	public String MyAppDetails() {
		return "yes.....";
	}	
}
