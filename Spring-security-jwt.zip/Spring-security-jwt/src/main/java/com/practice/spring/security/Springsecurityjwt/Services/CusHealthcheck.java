package com.practice.spring.security.Springsecurityjwt.Services;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Health.Builder;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;


@Component
public class CusHealthcheck implements HealthIndicator {

	@Override
	public Health health() {
	 
		Builder healthBuilder = new Health.Builder();
		
		boolean running = true;
        if (!(running)) {
        	System.out.println("working");
        	return  Health.up().build() ;
        } else {
        	return Health.down().build();
        }
		
		
		
	}

}
